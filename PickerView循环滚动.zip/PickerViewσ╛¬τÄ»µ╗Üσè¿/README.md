# pickerView
UIPickerView循环滚动,匹配预设值,以数组方式返回值
