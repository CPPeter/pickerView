//
//  AppDelegate.h
//  PickerView循环滚动
//
//  Created by apple on 16/3/14.
//  Copyright (c) 2016年 PC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

