//
//  ViewController.m
//  PickerView循环滚动
//
//  Created by apple on 16/3/14.
//  Copyright (c) 2016年 PC. All rights reserved.
//

#import "ViewController.h"
#import "CPCircularPickerView.h"


#define KScreetWith self.view.frame.size.width
#define KScreetHeight self.view.frame.size.height
#define Multiple    Multiple6 //

typedef enum : NSUInteger {
    Multiple4 = 4*4, //以最小一个数组为级数,如果大于等于50个,4*4倍放大
    Multiple6 = 6*4,//以最小一个数组为级数,如果大于等于20个,6*4倍放大
    Multiple11 = 11*4,//以最小一个数组为级数,如果大于等于10个,11*4倍放大
    Multiple21 = 21*4,//以最小一个数组为级数,如果大于等于5个,21*4倍放大
} MultipleNumber;

@interface ViewController ()<CPCircularPickerViewDelegate>
{
    BOOL   isFrist;
    NSInteger   componentNumber;
}

@property (nonatomic,strong)NSMutableArray              *dataArray;
@property (nonatomic,strong)CPCircularPickerView        *pickerView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    componentNumber = 0;
    // Do any additional setup after loading the view, typically from a nib.
    
    self.pickerView = [[CPCircularPickerView alloc]initWithNumberArray:nil delegate:self];
    self.pickerView.delegate = self;
    [self.view addSubview:self.pickerView];
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    btn.frame = CGRectMake(40, 40, 60, 30);
    btn.backgroundColor = [UIColor redColor];
    [btn addTarget:self action:@selector(btnAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn];
    CGFloat heitght = self.view.frame.size.height;
}
-(void)btnAction:(UIButton *)sender
{
    sender.selected = !sender.selected;
    if (sender.selected) {
        [self.pickerView show];
    }
    else
    {
        [self.pickerView cancelPicker];
    }
}

-(void)dataSourceHandle:(NSArray *)array{
    for (NSArray *subArray in array) {
        NSMutableArray *components = [[NSMutableArray alloc]init];
        for (int j = 0; j < Multiple; j++) {
            [components addObjectsFromArray:subArray];
        }
        [self.dataArray addObject:components];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma mark CPCircularPickerViewDelegate
-(void)pickerDidChaneStatus:(NSArray *)selectStrings
{
    NSLog(@"string=%@/n",selectStrings);
}

#pragma mark - 懒加载
-(NSMutableArray *)dataArray{
    if (!_dataArray) {
        _dataArray = [[NSMutableArray alloc]init];
    }
    return _dataArray;
}
@end
