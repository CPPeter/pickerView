//
//  CPCircularPickerView.h
//  PickerView循环滚动
//
//  Created by apple on 16/3/15.
//  Copyright (c) 2016年 PC. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol CPCircularPickerViewDelegate <NSObject>
@required
-(void)pickerDidChaneStatus:(NSArray *)selectStrings;

@end

@interface CPCircularPickerView : UIView

@property (nonatomic,assign)BOOL                                     isShowBarrierView;//!<是否显示遮挡层(default is YES)
@property (nonatomic,assign)BOOL                                     isShowEnterButton;//!<是否显示完成按钮(default is YES)
@property (nonatomic,weak)id<CPCircularPickerViewDelegate>           delegate;

-(instancetype)initWithNumberArray:(NSArray *)presetArray delegate:(id)delegate;
-(void)cancelPicker;
-(void)show;

@end
