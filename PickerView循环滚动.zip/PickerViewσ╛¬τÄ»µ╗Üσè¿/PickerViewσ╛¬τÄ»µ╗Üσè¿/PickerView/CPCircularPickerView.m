//
//  CPCircularPickerView.m
//  PickerView循环滚动
//
//  Created by apple on 16/3/14.
//  Copyright (c) 2016年 PC. All rights reserved.
//

#import "CPCircularPickerView.h"
#import "UIView+Frame.h"

#define KScreenWith   ([UIScreen mainScreen].bounds.size.width)
#define KScreenHeight    ([UIScreen mainScreen].bounds.size.height)

#define Multiple    Multiple6 //

typedef enum : NSUInteger {
    Multiple4 = 4*4, //以最小一个数组为级数,如果大于等于50个,4*4倍放大
    Multiple6 = 6*4,//以最小一个数组为级数,如果大于等于20个,6*4倍放大
    Multiple11 = 11*4,//以最小一个数组为级数,如果大于等于10个,11*4倍放大
    Multiple21 = 21*4,//以最小一个数组为级数,如果大于等于5个,21*4倍放大
} MultipleNumber;


@interface CPCircularPickerView ()<UIPickerViewDataSource,UIPickerViewDelegate>
{
    
}
@property (strong,nonatomic)UIView                                  *barrierView;//!<背景板
@property (nonatomic,strong)NSMutableArray                          *handleBackDataArray;
@property (nonatomic,strong)NSMutableArray                          *basicDataArray;
@property (nonatomic,strong)UIPickerView                            *circulatePickerView;
@property (nonatomic,strong)NSMutableArray                          *resultStringArray;
@property (nonatomic,strong)UIToolbar                               *enterToolBar;
@property (nonatomic,strong)UIView                                  *pickerBackgroundView;
@end

@implementation CPCircularPickerView


-(instancetype)initWithNumberArray:(NSArray *)presetArray delegate:(id <CPCircularPickerViewDelegate>)delegate{
    self = [super init];
    if (self) {
        CGFloat heigth = KScreenHeight - 64;
        UIViewController *viewController = (UIViewController *)delegate;
        if (!viewController.navigationController.navigationBarHidden) {
            heigth = KScreenHeight;
        }
        self.frame = CGRectMake(0, 0, KScreenWith, heigth);//需要依据外面是否有导航栏
        [self dataSourceHandle];
        self.delegate = delegate;
        [self creatPickerView:self.bounds];
        int forNumber = 0;
        for (int i = 0; i < presetArray.count ;i++){
            forNumber = i;
            NSString *presetString = presetArray[i];
            NSArray *baseicArray = self.basicDataArray[i];
            for (int j = 0; j < baseicArray.count; j++) {
                NSString *baseicString = baseicArray[j];
                if ([baseicString isEqualToString:presetString]) {
                    NSArray *array = self.handleBackDataArray[i];
                    [self.circulatePickerView selectRow:array.count/2+j inComponent:i animated:NO];
                    self.resultStringArray[i] = self.handleBackDataArray[i][array.count/2];
                }
            }
        }
        for (int i = forNumber; i < self.basicDataArray.count; i++) {
            NSArray *array = self.handleBackDataArray[i];
            [self.circulatePickerView selectRow:array.count/2 inComponent:i animated:NO];
            self.resultStringArray[i] = self.handleBackDataArray[i][array.count/2];
        }
        if (forNumber == 0) {
            NSArray *array = self.handleBackDataArray[0];
            //表示显示默认值
            [self pickerView:self.circulatePickerView didSelectRow:array.count/2 inComponent:0];
        }
        self.isShowEnterButton = YES;
        self.isShowBarrierView = YES;
        //先隐藏
        [self cancelPicker];
        
    }
    return self;
}
-(void)show{
    [UIView animateWithDuration:0.3 animations:^{
        self.pickerBackgroundView.y = self.height - self.pickerBackgroundView.height;
        self.barrierView.alpha = 0.6;
    }completion:^(BOOL finished) {
        self.alpha = 1;
    }];
}
-(void)cancelPicker{
    [UIView animateWithDuration:0.3 animations:^{
        self.pickerBackgroundView.y = self.height;
        self.barrierView.alpha = 0;
    }completion:^(BOOL finished) {
        self.alpha = 0;
    }];
}
-(void)destroy{
    self.delegate = nil;
    self.circulatePickerView = nil;
    [UIView animateWithDuration:0.3 animations:^{
        self.alpha = 0;
    }completion:^(BOOL finished) {
        [self removeFromSuperview];
    }];
    
}
-(void)creatPickerView:(CGRect)frame{
    [self addSubview:self.barrierView];
    [self addSubview:self.pickerBackgroundView];
    
}
-(void)dataSourceHandle{
    
    _basicDataArray = [NSMutableArray array];
    for (int j = 0; j< 3; j++) {
        NSMutableArray *subArray = [NSMutableArray array];
        for (int i = 0; i < 20; i++) {
            [subArray addObject:[NSString stringWithFormat:@"%d",i]];
        }
        [_basicDataArray addObject:subArray];
    }
    
    for (NSArray *subArray in _basicDataArray) {
        NSMutableArray *components = [[NSMutableArray alloc]init];
        for (int j = 0; j < Multiple; j++) {
            [components addObjectsFromArray:subArray];
        }
        [self.handleBackDataArray addObject:components];
    }
}
#pragma mark - UIPickerViewDataSource,UIPickerViewDelegate
-(NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return self.handleBackDataArray.count;
}
-(NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    NSArray *array = self.handleBackDataArray[component];
    return array.count;
}
-(UIView *)pickerView:(UIPickerView *)pickerView viewForRow:(NSInteger)row forComponent:(NSInteger)component reusingView:(UIView *)view{
    UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, KScreenWith/self.handleBackDataArray.count , 30)];
    NSArray *components = self.handleBackDataArray[component];
    label.backgroundColor = [UIColor clearColor];
    label.textColor = [UIColor blackColor];
    label.font = [UIFont systemFontOfSize:14];
    label.textAlignment = NSTextAlignmentCenter;
    label.text = components[row];
    return label;
}
-(void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    NSInteger count = row;
    NSArray *components = self.handleBackDataArray[component];
    if (row >= components.count / 4*3 ) {
        count = row%(components.count/Multiple) + 1 + components.count / 2;
    }
    if (row <= components.count / 4) {
        count = row%(components.count/Multiple) - 1 + components.count / 4 * 3;
    }
    [pickerView selectRow:count inComponent:component animated:NO];
    self.resultStringArray[component] = components[row];
    if ([self.delegate respondsToSelector:@selector(pickerDidChaneStatus:)]) {
        [self.delegate pickerDidChaneStatus:self.resultStringArray];
    }
}
-(NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component{
    NSArray *array = self.handleBackDataArray[component];
    return array[row];
}
-(void)setIsShowBarrierView:(BOOL)isShowBarrierView{
    self.barrierView.hidden = !isShowBarrierView;
}
-(void)setIsShowEnterButton:(BOOL)isShowEnterButton
{
    self.enterToolBar.hidden = !isShowEnterButton;
}

#pragma mark - 懒加载
-(NSMutableArray *)handleBackDataArray{
    if (!_handleBackDataArray) {
        _handleBackDataArray = [[NSMutableArray alloc]init];
    }
    return _handleBackDataArray;
}
-(UIPickerView *)circulatePickerView{
    if (!_circulatePickerView) {
        _circulatePickerView = [[UIPickerView alloc]initWithFrame:CGRectMake(0, self.enterToolBar.height, KScreenWith, 300)];
        _circulatePickerView.showsSelectionIndicator = YES;
        _circulatePickerView.delegate = self;
    }
    return _circulatePickerView;
}
-(UIView *)pickerBackgroundView{
    if (!_pickerBackgroundView) {
        _pickerBackgroundView = [[UIView alloc]initWithFrame:CGRectMake(0, self.height - 344, KScreenWith, CGRectGetMaxY(self.circulatePickerView.frame))];
        _pickerBackgroundView.backgroundColor = [UIColor clearColor];
        [_pickerBackgroundView addSubview:self.enterToolBar];
        [_pickerBackgroundView addSubview:self.circulatePickerView];
    }
    return _pickerBackgroundView;
}
-(UIView *)barrierView
{
    if (!_barrierView) {
        _barrierView = [[UIView alloc]initWithFrame:self.bounds];
        _barrierView.backgroundColor = [UIColor lightGrayColor];
        _barrierView.alpha = 0;
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(cancelPicker)];
        [_barrierView addGestureRecognizer:tap];
    }
    return _barrierView;
}
-(NSMutableArray *)resultStringArray{
    if (!_resultStringArray) {
        _resultStringArray = [[NSMutableArray alloc]initWithCapacity:self.handleBackDataArray.count];
    }
    return _resultStringArray;
}

-(UIToolbar *)enterToolBar{
    if (!_enterToolBar) {
        _enterToolBar = [[UIToolbar alloc]initWithFrame:CGRectMake(0, 0, KScreenWith, 44)];
        UIBarButtonItem *enter = [[UIBarButtonItem alloc]initWithTitle:@"完成" style:UIBarButtonItemStyleDone target:self action:@selector(cancelPicker)];
        _enterToolBar.items = @[enter];
    }
    return _enterToolBar;
}
@end
